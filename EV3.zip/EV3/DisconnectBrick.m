function DisconnectBrick(brickObject)
    delete(brickObject)
    clear brickObject
end