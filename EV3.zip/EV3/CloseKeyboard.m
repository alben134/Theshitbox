function CloseKeyboard
    global h
    close(h);
end